package quicksortcomparison;
//import java.util.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;


/**
 * Main class
 * @author 1513228
 * @version 1.0 06-Mar-2018
 */
public class MainApp {
    
// - - - - - - - - - - <FIELDS>
    
    /**
     * Number of comparisons
     */
    public static int nCompares;
    
    /**
     * Number of assignments
     */
    public static int nAssigns;
    
// - - - - - - - - - - </FIELDS>
    
    public static void main(String[] args) {

        //Comparable[] testArray = {2,6,3,2,8,9,5,9,1,8,4,2};
        //System.out.println( Arrays.toString(testArray) + "\n");
        
        //QuickSorter.quickSort( testArray, 0, testArray.length-1);
        //System.out.println( "\n" + Arrays.toString(testArray) );
        
        //QuickSorter.quickSortTwo( testArray, 0, testArray.length-1);
        //System.out.println( "\n" + Arrays.toString(testArray) );
        
        System.out.println(
                "Welcome to the QuickSort comparison.\n" + 
                "Once you have run the program, check the project folder.\n" +
                "There will be CSV files with the following information:\n" +
                " - The array size\n"+
                " - The average number of comparisons\n"+
                " - The average number of assignments\n\n"
        );
        quickSortOneExperiment();
        quickSortTwoExperiment();
        
        /*
        Comparable[] worstArray = new Comparable[100];
        for( int i = 0, j = 100 ; i < worstArray.length ; i++, j-- ){
            worstArray[i] = j;
        }
        System.out.println(Arrays.toString(worstArray) + "\n");
        QuickSorter.quickSort(worstArray, 0, worstArray.length-1);
        System.out.println(Arrays.toString(worstArray) + "\n");
        System.out.println(
                "\nNumber of comparisons " + MainApp.nCompares +
                "\nNumber of assignments " + MainApp.nAssigns
        );
        */

    }//End of main method
    
    /**
     * Quick Sort One Experiment
     * Creates a CSV file which contains data of the experiment
     * Each line in the file has the following:
     * - Size of the array
     * - Average number of comparisons
     * - Average number of Assignments
     */
    public static void quickSortOneExperiment() {
        try{
            
            System.out.println("QuickSort 01\n");
            
            // Create the file
            File file = new File("QuickSort01.csv");
            if (file.createNewFile()){
                System.out.println("File is created!");
            }else{
                System.out.println("File already exists.");
            }
            //Prepare the writer and write the file header
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write( "ArraySize,nCompares,nAssigns");
            writer.newLine();
            
            // Set the number of actions to count
            MainApp.nCompares = 0;
            MainApp.nAssigns = 0;
            
            // Number of repetitions
            int numReps = 100;
            
            // Array size
            int arraySize = 0;
            
            // Create the scanner
            Scanner in = new Scanner(System.in);
            
            // Range of numbers
            // Worst case
            System.out.println("What range of numbers would you like?");
            int rangeOfNumbers = in.nextInt();
            //int rangeOfNumbers = 0;
            
            // Maximum size
            System.out.println("What is the maximum size would you like?");
            int max = in.nextInt();
            
            // Increase of the size
            System.out.println("What increase would you like?");
            int increase = in.nextInt();
            
            // Increase the array size by 10 each time an experiment is performed
            //for( arraySize = 0 , rangeOfNumbers = 0 ; arraySize <= max ; arraySize += increase, rangeOfNumbers += increase ){
            for( arraySize = 0 ; arraySize <= max ; arraySize += increase ){

                // Do a quick sort for a number of times
                for (int i = 0; i < numReps; i++) {
                    Comparable[] a = ArrayGenerator.randomIntArray(arraySize, rangeOfNumbers);
                    // To record worst case
                    //MainApp.nCompares = 0;
                    //MainApp.nAssigns = 0;
                    QuickSorter.quickSort(a,0,a.length-1);
                }
                
                // Printing the experiment results in the file
                writer.write(
                    arraySize + "," +
                    1.0*MainApp.nCompares/numReps + "," +
                    1.0*MainApp.nAssigns/numReps
                );
                writer.newLine();
            }
            
            //Close the writer
            writer.flush();
            writer.close();
            
        } catch( Exception exception ){
            exception.printStackTrace();
        }
    }
    
    /**
     * Quick Sort One Experiment
     * Creates a CSV file which contains data of the experiment
     * Each line in the file has the following:
     * - Size of the array
     * - Average number of comparisons
     * - Average number of Assignments
     */
    public static void quickSortTwoExperiment() {
        try{
            
            System.out.println("QuickSort 02\n");
            
            // Create the file
            File file = new File("QuickSort02.csv");
            if (file.createNewFile()){
                System.out.println("File is created!");
            }else{
                System.out.println("File already exists.");
            }
            //Prepare the writer and write the file header
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write( "ArraySize,nCompares,nAssigns");
            writer.newLine();
            
            // Set the number of actions to count
            MainApp.nCompares = 0;
            MainApp.nAssigns = 0;
            
            // Number of repetitions
            int numReps = 100;
            
            // Array size
            int arraySize = 0;
            
            // Create the scanner
            Scanner in = new Scanner(System.in);
            
            // Range of numbers
            // Worst case
            System.out.println("What range of numbers would you like?");
            int rangeOfNumbers = in.nextInt();
            //int rangeOfNumbers = 0;
            
            // Maximum size
            System.out.println("What is the maximum size would you like?");
            int max = in.nextInt();
            
            // Increase of the size
            System.out.println("What increase would you like?");
            int increase = in.nextInt();
            
            // Increase the array size by 10 each time an experiment is performed
            //for( arraySize = 0 , rangeOfNumbers = 0 ; arraySize <= max ; arraySize += increase, rangeOfNumbers += increase ){
            for( arraySize = 0 ; arraySize <= max ; arraySize += increase ){
                
                // Do a quick sort for a number of times
                for (int i = 0; i < numReps; i++) {
                    Comparable[] a = ArrayGenerator.randomIntArray(arraySize, rangeOfNumbers);
                    // To record worst case
                    //MainApp.nCompares = 0;
                    //MainApp.nAssigns = 0;
                    QuickSorter.quickSortTwo(a,0,a.length-1);
                }
                
                // Printing the experiment results in the file
                writer.write(
                    arraySize + "," +
                    1.0 * MainApp.nCompares/numReps + "," +
                    1.0 * MainApp.nAssigns/numReps
                );
                writer.newLine();
            }
            
            //Close the writer
            writer.flush();
            writer.close();
            
        } catch( Exception exception ){
            exception.printStackTrace();
        }
    }
    
}//End of main class