package quicksortcomparison;

import java.util.Random;

//import java.util.*;

/**
 * Array Generator Class
 * @author 1513228
 * @version 1.0 16-Mar-2018
 */
public class ArrayGenerator {

    /**
     * Generate a random number
     */
    private static Random generator = new Random(); 

    /**
     * Creates an array of random integers
     * @param length    Array length
     * @param range     Range of possible values
     * @return Array filled with integer values
     */
    public static Comparable[] randomIntArray(int length, int range) {
        // Create an array of comparables
        Comparable[] a = new Integer[length];
        // For the length of the array
        for (int i = 0; i < a.length; i++) {
            // Fill the array with random integers
            a[i] = new Integer(generator.nextInt(range));
        }
        // Return the array
        return a;
    }
    
}//End of class