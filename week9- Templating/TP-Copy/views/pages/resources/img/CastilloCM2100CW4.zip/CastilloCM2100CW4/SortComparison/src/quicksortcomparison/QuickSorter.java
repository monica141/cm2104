package quicksortcomparison;

//import java.util.*;


/**
 * QuickSort Class
 * @author 1513228 - Sergio Castillo
 * @version March 2018
 */
public class QuickSorter {
    
    
/* < FIRST QUICK SORT > - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
    
    /**
     * First Quick Sort Algorithm
     * @param list
     * @param low
     * @param high 
     */
    public static void quickSort(Comparable[] list, int low, int high) {
        if(low < high){ 
            int p =  partition(list, low, high);
            quickSort(list, low, p-1);
            quickSort(list, p+1, high);
        }
    }
    
    /**
     * First Partition Method
     * @param list
     * @param low
     * @param high
     * @return 
     */
    public static int partition(Comparable[] list, int low, int high){
        Comparable pivot = list[low];
        int i = low + 1;
        int j = high;
        while( i <= j ){
            while( (i<=j) && (list[i].compareTo(pivot)<=0) ){
                i++;
                MainApp.nCompares++;
            }
            while( (j>=i) && (list[j].compareTo(pivot)>=0) ){
                j--;
                MainApp.nCompares++;
            }
            if(i<j){
                Comparable temp = list[i];
                list[i] = list[j];
                list[j] = temp;
                MainApp.nAssigns++;
            }
        }
        if( j!= low ){
            list[low] = list[j];
            list[j] = pivot;
            MainApp.nAssigns++;
        }
        return j;
    }
    
/* < SECOND QUICK SORT > - - - - - - - - - - - - - - - - - - - - - - - - - - - */
    
    /**
     * Second Quick Sort Method
     * @param list
     * @param low
     * @param high 
     */
    public static void quickSortTwo(Comparable[] list, int low, int high) {
        //Sort list Left...right into ascending order.
        if(low <= high){ 
            int p = partitionTwo(list, low, high);
            //Recursively, calls the quicksort with the different low and high 
            //parameter of the sub-array
            quickSortTwo(list, low, p-1);
            // System.out.println("\n" + Arrays.toString(list));
            quickSortTwo(list, p+1, high);
            // System.out.println("\n" + Arrays.toString(list));
        }
    }
    
    /**
     * Second Partition Method
     * @param list
     * @param low
     * @param high
     * @return 
     */
    public static int partitionTwo(Comparable[] list, int low, int high){
        int p = medianOfThree(list, low, (low+high)/2, high);
        if( p != low ){
            Comparable temp = list[p];
            list[p] = list[low];
            list[low] = temp;
        }
        Comparable pivot = list[low];
        int i = low + 1;
        int j = high;
        while( i <= j ){
            while( (i<=j) && (list[i].compareTo(pivot)<=0) ){
                i++;
                MainApp.nCompares++;
            }
            while( (j>=i) && (list[j].compareTo(pivot)>=0) ){
                j--;
                MainApp.nCompares++;
            }
            if(i<j){
                Comparable temp = list[i];
                list[i] = list[j];
                list[j] = temp;
                MainApp.nAssigns++;
            }
        }
        if( j!= low ){
            list[low] = list[j];
            list[j] = pivot;
            MainApp.nAssigns++;
        }
        return j;
    }
    
    /**
     * Median element Method
     * @param list
     * @param low
     * @param mid
     * @param high
     * @return 
     */
    public static int medianOfThree(Comparable[] list, int low, int mid, int high) {
        /* Return median position in array of elements
        * list[low], list[mid], and list[right] */
        if (list[low].compareTo(list[mid])< 0) {
        if (list[mid].compareTo(list[high]) < 0) return mid;
           else if(list[low].compareTo(list[high]) < 0) return high;
           else return low;
       } else {
           if (list[mid].compareTo(list[high]) > 0) return mid;
           else if (list[low].compareTo(list[high]) > 0) return high;
           else return low;
       }
    }
    
}





